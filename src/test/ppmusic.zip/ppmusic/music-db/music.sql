-- 数据库
drop database if exists `ppmusic`;
create database if not exists `ppmusic` character set utf8;
-- 使用数据库
use `ppmusic`;

-- 创建user
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
`id` INT PRIMARY KEY AUTO_INCREMENT,
`username` varchar(20) NOT NULL,
`password` varchar(255) NOT NULL
)default charset 'utf8';
INSERT INTO user(username,password)
VALUES('admin','$2a$10$Bs4wNEkledVlGZa6wSfX7eCSD7wRMO0eUwkJH0WyhXzKQJrnk85li');

-- 创建music
DROP TABLE IF EXISTS `music`;
CREATE TABLE `music` (
`id` int PRIMARY KEY AUTO_INCREMENT,
`title` varchar(50) NOT NULL,
`singer` varchar(30) NOT NULL,
`time` varchar(13) NOT NULL,
`url` varchar(1000) NOT NULL,
`userid` int(11) NOT NULL
)default charset 'utf8';

-- 创建favourite
DROP TABLE IF EXISTS `favourite`;
CREATE TABLE `favourite` (
`id` int PRIMARY KEY AUTO_INCREMENT,
`user_id` int(11) NOT NULL,
`music_id` int(11) NOT NULL
)default charset 'utf8';
